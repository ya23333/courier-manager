import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import { BrowserMultiFormatReader } from "@zxing/browser";
import * as XLSX from "xlsx";
import {
  Activity, ArrowDownToLine, ArrowUpFromLine, Barcode, Box, Check, CheckCircle2,
  ChevronDown, CircleDollarSign, ClipboardList, Cloud, FileSpreadsheet, Filter,
  LayoutDashboard, LogOut, Menu, Package, Plus, RefreshCw, ScanLine, Search,
  ShieldCheck, Truck, Users, Wallet, X, AlertCircle, UserPlus, Settings, Clock3
} from "lucide-react";
import { configured, supabase } from "./supabase";
import "./style.css";

const money = n => `${Number(n || 0).toFixed(2)} DT`;
const statusLabels = { pending:"À distribuer", assigned:"Assigné", delivered:"Livré", absent:"Absent", refused:"Refusé", returned:"Retour dépôt" };
const statusColors = { pending:"gray", assigned:"blue", delivered:"green", absent:"amber", refused:"red", returned:"purple" };

function App() {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);
  const [configError, setConfigError] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loginError, setLoginError] = useState("");
  const [tab, setTab] = useState("dashboard");
  const [shipments, setShipments] = useState([]);
  const [couriers, setCouriers] = useState([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [selected, setSelected] = useState([]);
  const [assignTo, setAssignTo] = useState("");
  const [busy, setBusy] = useState(false);
  const [notice, setNotice] = useState("");
  const [scanOpen, setScanOpen] = useState(false);
  const [scanText, setScanText] = useState("");
  const [manualCode, setManualCode] = useState("");
  const [codInput, setCodInput] = useState("");
  const [commissionInput, setCommissionInput] = useState("4");
  const [editingCourier, setEditingCourier] = useState("");
  const fileRef = useRef(null);
  const videoRef = useRef(null);
  const scannerRef = useRef(null);

  const isAdmin = profile?.role === "admin";

  useEffect(() => {
    if (!configured) { setConfigError("L'application doit être connectée à votre projet Supabase. Consultez le guide README."); setLoading(false); return; }
    supabase.auth.getSession().then(({ data }) => setSession(data.session));
    const { data: listener } = supabase.auth.onAuthStateChange((_event, next) => setSession(next));
    return () => listener.subscription.unsubscribe();
  }, []);

  useEffect(() => {
    let alive = true;
    async function loadProfile() {
      if (!session?.user) { setProfile(null); setShipments([]); setCouriers([]); setLoading(false); return; }
      setLoading(true);
      const { data, error } = await supabase.from("profiles").select("*").eq("id", session.user.id).single();
      if (!alive) return;
      if (error) setLoginError("Profil introuvable. L'administrateur doit attribuer votre rôle dans Supabase.");
      else { setProfile(data); setLoginError(""); }
      setLoading(false);
    }
    loadProfile();
    return () => { alive = false; };
  }, [session]);

  const loadData = async () => {
    if (!profile) return;
    setBusy(true);
    let q = supabase.from("shipments").select("*").order("created_at", { ascending: false });
    if (!isAdmin) q = q.eq("assigned_to", profile.id);
    const { data, error } = await q;
    if (error) setNotice(error.message); else setShipments(data || []);
    if (isAdmin) {
      const { data: people, error: peopleError } = await supabase.from("profiles").select("*").eq("role", "courier").order("created_at");
      if (peopleError) setNotice(peopleError.message); else setCouriers(people || []);
    }
    setBusy(false);
  };

  useEffect(() => {
    loadData();
    if (!profile) return;
    const channel = supabase.channel("courier-live-" + profile.id)
      .on("postgres_changes", { event: "*", schema: "public", table: "shipments" }, loadData)
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, loadData)
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [profile?.id, profile?.role]);

  const visibleShipments = useMemo(() => shipments.filter(s => {
    const q = search.toLowerCase();
    const matches = !q || [s.tracking_code,s.customer_name,s.phone,s.address].some(v => String(v || "").toLowerCase().includes(q));
    return matches && (filter === "all" || s.status === filter);
  }), [shipments, search, filter]);

  const delivered = shipments.filter(s => s.status === "delivered");
  const totalCOD = delivered.reduce((a,s) => a + Number(s.cod_amount || 0), 0);
  const personalCommission = isAdmin ? delivered.filter(s => s.assigned_to === profile?.id).length * 5 : delivered.length * Number(profile?.commission_rate ?? 4);
  const teamCommission = isAdmin ? delivered.filter(s => s.assigned_to && s.assigned_to !== profile?.id).reduce((a,s) => a + Number(s.commission_rate ?? 4), 0) : 0;
  const adminMargin = isAdmin ? delivered.filter(s => s.assigned_to && s.assigned_to !== profile?.id).reduce((a,s) => a + Math.max(0, 5 - Number(s.commission_rate ?? 4)), 0) : 0;
  const toRemit = totalCOD - personalCommission - (isAdmin ? teamCommission : 0);

  async function signIn(e) {
    e.preventDefault(); setLoginError("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) setLoginError(error.message);
  }
  async function signOut() { await supabase.auth.signOut(); setProfile(null); }

  async function importExcel(file) {
    if (!file || !isAdmin) return;
    setBusy(true); setNotice("");
    try {
      const buffer = await file.arrayBuffer();
      const workbook = XLSX.read(buffer, { type: "array" });
      const rows = XLSX.utils.sheet_to_json(workbook.Sheets[workbook.SheetNames[0]], { defval: "" });
      const normalize = obj => Object.fromEntries(Object.entries(obj).map(([k,v]) => [String(k).trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g,""), v]));
      const records = rows.map(raw => {
        const r = normalize(raw);
        const pick = (...keys) => { for (const k of keys) if (r[k] !== undefined && r[k] !== "") return r[k]; return ""; };
        const code = String(pick("code","code colis","tracking_code","tracking","barcode","reference","ref","numero colis","n° colis")).trim();
        if (!code) return null;
        return {
          tracking_code: code,
          customer_name: String(pick("client","nom","nom client","customer","customer_name","destinataire")).trim(),
          phone: String(pick("telephone","tel","phone","gsm","mobile")).trim(),
          address: String(pick("adresse","address","adresse client","destination")).trim(),
          cod_amount: Number(String(pick("cod","montant","montant cod","prix","amount","a encaisser") || 0).replace(",", ".")) || 0,
          status: "pending", created_by: profile.id
        };
      }).filter(Boolean);
      if (!records.length) throw new Error("Aucun code colis trouvé. Vérifiez les colonnes Excel.");
      const { data, error } = await supabase.from("shipments").upsert(records, { onConflict: "tracking_code", ignoreDuplicates: true }).select();
      if (error) throw error;
      setNotice(`${records.length} lignes lues. Les nouveaux colis ont été importés (les codes déjà existants sont ignorés).`);
      await loadData();
    } catch (e) { setNotice("Import impossible : " + e.message); }
    finally { setBusy(false); if (fileRef.current) fileRef.current.value = ""; }
  }

  async function assignSelected() {
    if (!assignTo || !selected.length) return;
    setBusy(true);
    const isSelf = assignTo === profile.id;
    const courier = couriers.find(c => c.id === assignTo);
    const { error } = await supabase.from("shipments").update({
      assigned_to: assignTo, status: "assigned", commission_rate: isSelf ? 5 : Number(courier?.commission_rate ?? 4),
      assigned_at: new Date().toISOString()
    }).in("id", selected).eq("status", "pending");
    if (error) setNotice(error.message);
    else { setNotice(`${selected.length} colis affecté(s).`); setSelected([]); await loadData(); }
    setBusy(false);
  }

  async function updateStatus(shipment, status) {
    const updates = { status, updated_at: new Date().toISOString() };
    if (status === "delivered") updates.delivered_at = new Date().toISOString();
    const { error } = await supabase.from("shipments").update(updates).eq("id", shipment.id);
    if (error) setNotice(error.message); else { setNotice("Statut mis à jour."); await loadData(); }
  }

  async function scanLookup(code) {
    const clean = String(code || "").trim();
    if (!clean) return;
    const found = shipments.find(s => s.tracking_code.toLowerCase() === clean.toLowerCase());
    if (found) { setScanText(found.tracking_code); setNotice(`Colis ${found.tracking_code} : ${found.customer_name || "Client"} — ${found.address || "Adresse non renseignée"} — COD ${money(found.cod_amount)}.`); }
    else setNotice("Code non trouvé dans les colis qui vous sont attribués.");
  }

  function startScanner() { setScanOpen(true); }
  useEffect(() => {
    if (!scanOpen || !videoRef.current) return;
    const reader = new BrowserMultiFormatReader();
    scannerRef.current = reader;
    reader.decodeFromVideoDevice(undefined, videoRef.current, (result) => {
      if (result) {
        const text = result.getText();
        reader.reset();
        setManualCode(text);
        setScanOpen(false);
        scanLookup(text);
      }
    }).catch(() => setNotice("Caméra inaccessible. Autorisez la caméra et utilisez HTTPS, ou saisissez le code manuellement."));
    return () => { try { reader.reset(); } catch {} };
  }, [scanOpen]);
  function stopScanner() { try { scannerRef.current?.reset(); } catch {} setScanOpen(false); }

  async function saveCommission() {
    if (!editingCourier) return;
    const rate = Number(commissionInput);
    if (!Number.isFinite(rate) || rate < 0 || rate > 100) { setNotice("Commission invalide."); return; }
    const { error } = await supabase.from("profiles").update({ commission_rate: rate }).eq("id", editingCourier);
    if (error) setNotice(error.message); else { setNotice("Commission mise à jour."); setEditingCourier(""); await loadData(); }
  }

  if (loading) return <div className="center"><div className="loader"/>Chargement…</div>;
  if (!configured) return <Setup configError={configError}/>;
  if (!session) return <div className="login-wrap"><div className="login-card"><div className="brand-mark"><Truck/></div><div className="eyebrow">GESTION DE LIVRAISON</div><h1>Courier Manager</h1><p>Connectez-vous à votre espace sécurisé.</p><form onSubmit={signIn}><label>Email</label><input type="email" required value={email} onChange={e=>setEmail(e.target.value)} placeholder="admin@exemple.tn"/><label>Mot de passe</label><input type="password" required value={password} onChange={e=>setPassword(e.target.value)} placeholder="••••••••"/><button className="primary full">Se connecter</button></form>{loginError && <div className="alert error">{loginError}</div>}</div></div>;

  if (!profile) return <div className="center"><div className="alert error">Compte connecté mais profil absent. Demandez à l'administrateur de configurer votre rôle.</div><button onClick={signOut}>Déconnexion</button></div>;

  return <div className="app-shell">
    <aside className="sidebar">
      <div className="brand"><div className="brand-mark small"><Truck/></div><div><b>Courier Manager</b><small>Gestion & comptabilité</small></div></div>
      <div className="user-box"><div className="avatar">{(profile.full_name || session.user.email).slice(0,1).toUpperCase()}</div><div><b>{profile.full_name || session.user.email}</b><small>{isAdmin ? "Administrateur" : "Livreur"}</small></div><span className="online-dot"/></div>
      <nav>
        <button className={tab==="dashboard"?"active":""} onClick={()=>setTab("dashboard")}><LayoutDashboard/>Vue générale</button>
        <button className={tab==="shipments"?"active":""} onClick={()=>setTab("shipments")}><Package/>Colis</button>
        {isAdmin && <button className={tab==="assign"?"active":""} onClick={()=>setTab("assign")}><ArrowUpFromLine/>Affectation</button>}
        {isAdmin && <button className={tab==="team"?"active":""} onClick={()=>setTab("team")}><Users/>Livreurs</button>}
        <button className={tab==="scan"?"active":""} onClick={()=>setTab("scan")}><ScanLine/>Scanner</button>
        <button className={tab==="finance"?"active":""} onClick={()=>setTab("finance")}><Wallet/>Comptabilité</button>
      </nav>
      <div className="sidebar-bottom"><div className="sync-state"><span className="online-dot"/> Synchronisation active</div><button className="logout" onClick={signOut}><LogOut/>Déconnexion</button></div>
    </aside>
    <main className="main">
      <header className="topbar"><div><div className="eyebrow">{isAdmin?"ESPACE ADMINISTRATEUR":"ESPACE LIVREUR"}</div><h1>{({dashboard:"Vue générale",shipments:"Gestion des colis",assign:"Affectation des colis",team:"Gestion des livreurs",scan:"Scanner un colis",finance:"Comptabilité"})[tab]}</h1></div><div className="top-actions"><span className="live-pill"><span className="online-dot"/> En ligne</span><button className="icon-btn" onClick={loadData} title="Actualiser"><RefreshCw/></button></div></header>
      {notice && <div className="notice"><span>{notice}</span><button onClick={()=>setNotice("")}><X/></button></div>}
      {tab==="dashboard" && <Dashboard isAdmin={isAdmin} shipments={shipments} delivered={delivered} totalCOD={totalCOD} personalCommission={personalCommission} teamCommission={teamCommission} adminMargin={adminMargin} toRemit={toRemit} couriers={couriers}/>}
      {tab==="shipments" && <Shipments shipments={visibleShipments} search={search} setSearch={setSearch} filter={filter} setFilter={setFilter} isAdmin={isAdmin} onStatus={updateStatus} onImport={()=>fileRef.current?.click()} busy={busy}/>}
      {tab==="assign" && isAdmin && <Assign shipments={shipments.filter(s=>s.status==="pending")} couriers={couriers} adminProfile={profile} selected={selected} setSelected={setSelected} assignTo={assignTo} setAssignTo={setAssignTo} onAssign={assignSelected} busy={busy}/>}
      {tab==="team" && isAdmin && <Team couriers={couriers} onEdit={(c)=>{setEditingCourier(c.id);setCommissionInput(String(c.commission_rate ?? 4));}}/>}
      {tab==="scan" && <ScanPage isAdmin={isAdmin} manualCode={manualCode} setManualCode={setManualCode} onLookup={scanLookup} onCamera={startScanner} shipments={shipments} onStatus={updateStatus}/>}
      {tab==="finance" && <Finance isAdmin={isAdmin} shipments={shipments} couriers={couriers} personalCommission={personalCommission} teamCommission={teamCommission} adminMargin={adminMargin} toRemit={toRemit}/>}
      <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" hidden onChange={e=>importExcel(e.target.files?.[0])}/>
      {scanOpen && <div className="modal-backdrop"><div className="modal"><div className="modal-head"><b>Scanner le code-barres</b><button className="icon-btn" onClick={stopScanner}><X/></button></div><video ref={videoRef} className="scanner-video"/><p className="muted">Placez le code-barres dans le cadre. Autorisez l'accès à la caméra.</p><button className="secondary full" onClick={stopScanner}>Fermer le scanner</button></div></div>}
      {editingCourier && <div className="modal-backdrop"><div className="modal"><div className="modal-head"><b>Modifier la commission</b><button className="icon-btn" onClick={()=>setEditingCourier("")}><X/></button></div><label>Commission par colis livré (DT)</label><input type="number" min="0" step="0.5" value={commissionInput} onChange={e=>setCommissionInput(e.target.value)}/><button className="primary full" onClick={saveCommission}>Enregistrer</button></div></div>}
    </main>
  </div>;
}

function Setup({configError}) {
  return <div className="login-wrap"><div className="login-card setup-card"><div className="brand-mark"><Truck/></div><div className="eyebrow">PREMIÈRE CONFIGURATION</div><h1>Courier Manager</h1><p>{configError}</p><div className="setup-steps"><b>À faire :</b><ol><li>Créer un projet Supabase.</li><li>Copier l'URL et la clé publique dans le fichier <code>.env</code>.</li><li>Exécuter le script <code>supabase/schema.sql</code>.</li><li>Créer le compte administrateur et les comptes livreurs selon le guide README.</li></ol></div></div></div>;
}

function Dashboard({isAdmin,shipments,delivered,totalCOD,personalCommission,teamCommission,adminMargin,toRemit,couriers}) {
  const count = status => shipments.filter(s=>s.status===status).length;
  return <div className="content">
    <div className="stats-grid">
      <Stat icon={<Package/>} label="Total colis visibles" value={shipments.length}/>
      <Stat icon={<CheckCircle2/>} label="Livrés" value={count("delivered")} tone="green"/>
      <Stat icon={<Clock3/>} label="En attente / affectés" value={count("pending")+count("assigned")} tone="blue"/>
      <Stat icon={<CircleDollarSign/>} label="COD encaissé (livrés)" value={money(totalCOD)} tone="amber"/>
    </div>
    <div className="two-col">
      <section className="panel"><div className="panel-title"><h2>{isAdmin?"Résumé de votre activité":"Mon activité"}</h2><span className="muted">Colis livrés uniquement</span></div><div className="finance-highlight"><div><span>{isAdmin?"Commission personnelle":"Ma commission"}</span><strong>{money(personalCommission)}</strong></div>{isAdmin && <div><span>Marge sur l'équipe</span><strong className="green-text">{money(adminMargin)}</strong></div>}</div>{isAdmin && <div className="mini-row"><span>Commissions livreurs à payer</span><b>{money(teamCommission)}</b></div>}<div className="mini-row"><span>À remettre au dépôt (estimation)</span><b>{money(toRemit)}</b></div><p className="tiny muted">Le calcul suppose que la commission est déduite du COD. Vérifiez le mode de règlement réel avec l'expéditeur.</p></section>
      <section className="panel"><div className="panel-title"><h2>Répartition des statuts</h2></div><div className="status-list">{Object.entries(statusLabels).map(([key,label])=><div className="status-line" key={key}><span className={`dot ${statusColors[key]}`}/><span>{label}</span><b>{count(key)}</b></div>)}</div></section>
    </div>
    {isAdmin && <section className="panel"><div className="panel-title"><h2>Équipe</h2><span className="muted">{couriers.length} compte(s) livreur</span></div>{couriers.length===0?<Empty text="Aucun livreur configuré pour le moment."/>:<div className="courier-grid">{couriers.map(c=><div className="courier-card" key={c.id}><div className="avatar">{(c.full_name||"?").slice(0,1)}</div><div><b>{c.full_name}</b><small>{money(c.commission_rate)} / colis livré</small></div></div>)}</div>}</section>}
  </div>;
}
function Stat({icon,label,value,tone=""}) { return <div className="stat-card"><div className={`stat-icon ${tone}`}>{icon}</div><div><span>{label}</span><strong>{value}</strong></div></div>; }
function Empty({text}) { return <div className="empty"><Package/><p>{text}</p></div>; }

function Shipments({shipments,search,setSearch,filter,setFilter,isAdmin,onStatus,onImport,busy}) {
  return <div className="content"><section className="panel"><div className="toolbar"><div className="searchbox"><Search/><input placeholder="Code, client, téléphone, adresse…" value={search} onChange={e=>setSearch(e.target.value)}/></div><select value={filter} onChange={e=>setFilter(e.target.value)}><option value="all">Tous les statuts</option>{Object.entries(statusLabels).map(([k,v])=><option value={k} key={k}>{v}</option>)}</select>{isAdmin&&<button className="primary" onClick={onImport} disabled={busy}><FileSpreadsheet/> Importer Excel</button>}</div><div className="table-wrap"><table><thead><tr><th>Code colis</th><th>Client</th><th>Téléphone</th><th>Adresse</th><th>COD</th><th>Statut</th><th>Action</th></tr></thead><tbody>{shipments.map(s=><tr key={s.id}><td><b>{s.tracking_code}</b></td><td>{s.customer_name||"—"}</td><td>{s.phone||"—"}</td><td className="address-cell">{s.address||"—"}</td><td>{money(s.cod_amount)}</td><td><span className={`status-badge ${statusColors[s.status]}`}>{statusLabels[s.status]}</span></td><td><select className="small-select" value={s.status} onChange={e=>onStatus(s,e.target.value)}><option value="pending">À distribuer</option><option value="assigned">Assigné</option><option value="delivered">Livré</option><option value="absent">Absent</option><option value="refused">Refusé</option><option value="returned">Retour dépôt</option></select></td></tr>)}</tbody></table>{shipments.length===0&&<Empty text="Aucun colis ne correspond à votre recherche."/ >}</div></section></div>;
}

function Assign({shipments,couriers,adminProfile,selected,setSelected,assignTo,setAssignTo,onAssign,busy}) {
  return <div className="content"><div className="panel"><div className="panel-title"><div><h2>Distribuer les colis</h2><p className="muted">Sélectionnez les colis à affecter à un livreur.</p></div><span className="count-pill">{shipments.length} disponibles</span></div>{<><div className="assign-toolbar"><label className="select-all"><input type="checkbox" checked={selected.length===shipments.length&&shipments.length>0} onChange={e=>setSelected(e.target.checked?shipments.map(s=>s.id):[])}/> Tout sélectionner</label><select value={assignTo} onChange={e=>setAssignTo(e.target.value)}><option value="">Choisir un livreur…</option><option value={adminProfile.id}>Moi-même (Admin) — 5.00 DT</option>{couriers.map(c=><option value={c.id} key={c.id}>{c.full_name} — {money(c.commission_rate)}</option>)}</select><button className="primary" disabled={!selected.length||!assignTo||busy} onClick={onAssign}><ArrowUpFromLine/> Affecter {selected.length} colis</button></div><div className="assign-list">{shipments.map(s=><label className="assign-item" key={s.id}><input type="checkbox" checked={selected.includes(s.id)} onChange={e=>setSelected(old=>e.target.checked?[...old,s.id]:old.filter(x=>x!==s.id))}/><div><b>{s.tracking_code}</b><small>{s.customer_name} · {s.address}</small></div><strong>{money(s.cod_amount)}</strong></label>)}</div></>}</div></div>;
}

function Team({couriers,onEdit}) {
  return <div className="content"><section className="panel"><div className="panel-title"><div><h2>Mes livreurs</h2><p className="muted">Comptes et commissions. La création sécurisée des utilisateurs se fait depuis l'administration Supabase dans cette première version.</p></div><Users/></div>{couriers.length===0?<Empty text="Aucun compte livreur configuré."/>:<div className="team-table">{couriers.map(c=><div className="team-row" key={c.id}><div className="avatar">{(c.full_name||"?").slice(0,1)}</div><div className="team-person"><b>{c.full_name}</b><small>{c.email||"Compte livreur"}</small></div><div className="rate">{money(c.commission_rate)} <small>/ livré</small></div><button className="secondary" onClick={()=>onEdit(c)}><Settings/> Commission</button></div>)}</div>}</section></div>;
}

function ScanPage({isAdmin,manualCode,setManualCode,onLookup,onCamera,shipments,onStatus}) {
  const found = shipments.find(s=>s.tracking_code.toLowerCase()===manualCode.trim().toLowerCase());
  return <div className="content"><div className="scan-layout"><section className="panel scan-panel"><div className="scan-illustration"><Barcode size={54}/></div><h2>Scanner un colis</h2><p className="muted">Scannez l'étiquette ou saisissez le code de suivi.</p><button className="primary full" onClick={onCamera}><ScanLine/> Ouvrir la caméra</button><div className="or-divider">ou saisie manuelle</div><div className="manual-row"><input value={manualCode} onChange={e=>setManualCode(e.target.value)} placeholder="Code colis…"/><button className="secondary" onClick={()=>onLookup(manualCode)}><Search/> Chercher</button></div><small className="muted">La caméra nécessite HTTPS et l'autorisation d'accès.</small><button id="open-camera" hidden/></section>{found&&<section className="panel parcel-detail"><div className="panel-title"><h2>Informations du colis</h2><span className={`status-badge ${statusColors[found.status]}`}>{statusLabels[found.status]}</span></div><h3>{found.customer_name}</h3><p>{found.phone}</p><p>{found.address}</p><div className="cod-box"><span>Montant à encaisser</span><b>{money(found.cod_amount)}</b></div>{!isAdmin&&<div className="status-actions"><button className="primary" onClick={()=>onStatus(found,"delivered")}>Livré</button><button className="secondary" onClick={()=>onStatus(found,"absent")}>Absent</button><button className="danger" onClick={()=>onStatus(found,"refused")}>Refusé</button></div>}</section>}</div></div>;
}

function Finance({isAdmin,shipments,couriers,personalCommission,teamCommission,adminMargin,toRemit}) {
  const delivered = shipments.filter(s=>s.status==="delivered");
  const rows = isAdmin ? couriers.map(c=>{const list=delivered.filter(s=>s.assigned_to===c.id);return {...c,count:list.length,cod:list.reduce((a,s)=>a+Number(s.cod_amount||0),0),commission:list.length*Number(c.commission_rate||4)}}) : [];
  return <div className="content"><div className="stats-grid"><Stat icon={<Wallet/>} label="COD encaissé" value={money(delivered.reduce((a,s)=>a+Number(s.cod_amount||0),0))}/><Stat icon={<CircleDollarSign/>} label={isAdmin?"Votre commission":"Ma commission"} value={money(personalCommission)} tone="green"/>{isAdmin&&<Stat icon={<Activity/>} label="Marge équipe" value={money(adminMargin)} tone="blue"/>}<Stat icon={<ArrowDownToLine/>} label="À remettre dépôt" value={money(toRemit)} tone="amber"/></div>{isAdmin&&<section className="panel"><div className="panel-title"><h2>Récapitulatif par livreur</h2></div><div className="table-wrap"><table><thead><tr><th>Livreur</th><th>Colis livrés</th><th>COD encaissé</th><th>Commission</th><th>Marge admin</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td><b>{r.full_name}</b></td><td>{r.count}</td><td>{money(r.cod)}</td><td>{money(r.commission)}</td><td>{money(r.count)}</td></tr>)}</tbody></table></div></section>}<section className="panel"><div className="panel-title"><h2>Détail des colis livrés</h2><span className="muted">{delivered.length} colis</span></div><div className="table-wrap"><table><thead><tr><th>Code</th><th>Client</th><th>COD</th><th>Commission</th><th>Date livraison</th></tr></thead><tbody>{delivered.map(s=><tr key={s.id}><td>{s.tracking_code}</td><td>{s.customer_name}</td><td>{money(s.cod_amount)}</td><td>{money(isAdmin?(s.assigned_to===null?5:Number(s.commission_rate===4?1:Math.max(0,5-Number(s.commission_rate||4)))):Number(profileRateFallback(s)))}</td><td>{s.delivered_at?new Date(s.delivered_at).toLocaleString("fr-TN"):"—"}</td></tr>)}</tbody></table></div></section></div>;
}
function profileRateFallback(s){return s.commission_rate||4;}

createRoot(document.getElementById("root")).render(<App/>);
