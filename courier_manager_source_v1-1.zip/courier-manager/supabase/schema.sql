-- Courier Manager database schema for Supabase
-- Run this in Supabase SQL Editor as project owner.

create extension if not exists pgcrypto;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default '',
  email text,
  role text not null default 'courier' check (role in ('admin','courier')),
  commission_rate numeric(8,2) not null default 4 check (commission_rate >= 0),
  created_at timestamptz not null default now()
);

create table if not exists public.shipments (
  id uuid primary key default gen_random_uuid(),
  tracking_code text not null unique,
  customer_name text not null default '',
  phone text not null default '',
  address text not null default '',
  cod_amount numeric(10,2) not null default 0 check (cod_amount >= 0),
  status text not null default 'pending' check (status in ('pending','assigned','delivered','absent','refused','returned')),
  created_by uuid references public.profiles(id),
  assigned_to uuid references public.profiles(id),
  commission_rate numeric(8,2) not null default 4,
  assigned_at timestamptz,
  delivered_at timestamptz,
  updated_at timestamptz not null default now(),
  created_at timestamptz not null default now()
);

create index if not exists shipments_assigned_to_idx on public.shipments(assigned_to);
create index if not exists shipments_status_idx on public.shipments(status);

create or replace function public.current_user_is_admin()
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (select 1 from public.profiles where id = auth.uid() and role = 'admin');
$$;

alter table public.profiles enable row level security;
alter table public.shipments enable row level security;

drop policy if exists "profile read self or admin" on public.profiles;
create policy "profile read self or admin" on public.profiles
for select using (id = auth.uid() or public.current_user_is_admin());

drop policy if exists "admin update profiles" on public.profiles;
create policy "admin update profiles" on public.profiles
for update using (public.current_user_is_admin()) with check (public.current_user_is_admin());

drop policy if exists "shipments visible to admin or assigned courier" on public.shipments;
create policy "shipments visible to admin or assigned courier" on public.shipments
for select using (public.current_user_is_admin() or assigned_to = auth.uid() or created_by = auth.uid());

drop policy if exists "admin inserts shipments" on public.shipments;
create policy "admin inserts shipments" on public.shipments
for insert with check (public.current_user_is_admin());

drop policy if exists "admin or assigned courier updates shipment" on public.shipments;
create policy "admin or assigned courier updates shipment" on public.shipments
for update using (public.current_user_is_admin() or assigned_to = auth.uid())
with check (public.current_user_is_admin() or assigned_to = auth.uid());

-- Prevent a courier from changing assignment, customer data, COD, or commission.
create or replace function public.guard_courier_shipment_update()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if not public.current_user_is_admin() then
    if old.assigned_to is distinct from auth.uid()
       or new.assigned_to is distinct from old.assigned_to
       or new.tracking_code is distinct from old.tracking_code
       or new.customer_name is distinct from old.customer_name
       or new.phone is distinct from old.phone
       or new.address is distinct from old.address
       or new.cod_amount is distinct from old.cod_amount
       or new.commission_rate is distinct from old.commission_rate
       or new.created_by is distinct from old.created_by
       or new.assigned_at is distinct from old.assigned_at then
      raise exception 'Livreur non autorisé à modifier ces informations';
    end if;
    if new.status not in ('delivered','absent','refused','returned') then
      raise exception 'Statut non autorisé';
    end if;
  end if;
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists guard_courier_shipment_update on public.shipments;
create trigger guard_courier_shipment_update before update on public.shipments
for each row execute function public.guard_courier_shipment_update();

-- IMPORTANT: create the first admin user in Supabase Authentication first,
-- then replace ADMIN_USER_UUID below with that user's Auth UID and run:
-- insert into public.profiles (id, full_name, email, role, commission_rate)
-- values ('ADMIN_USER_UUID', 'Admin', 'admin@example.tn', 'admin', 5);

-- For each courier, create the user in Authentication, then add their profile:
-- insert into public.profiles (id, full_name, email, role, commission_rate)
-- values ('COURIER_AUTH_UUID', 'Livreur 1', 'livreur1@example.tn', 'courier', 4);

-- Enable Realtime for shipment and profile changes in Supabase Dashboard:
-- Database > Replication > enable profiles and shipments.
