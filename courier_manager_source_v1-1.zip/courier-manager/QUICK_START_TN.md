# بداية سريعة — Courier Manager

1. اعمل مشروع Supabase.
2. نفّذ `supabase/schema.sql` في SQL Editor.
3. أنشئ حسابك في Authentication > Users.
4. خذ الـ UID متاع حسابك، وبعد نفّذ INSERT الـ Admin الموجود في آخر `schema.sql`.
5. أنشئ حسابات الـ livreurs في Authentication > Users، ولكل واحد زِد profile بدور `courier` وعمولة `4`.
6. فعّل Realtime لجدولي `shipments` و`profiles`.
7. انسخ `.env.example` إلى `.env` وحط URL و anon key.
8. شغّل `npm install` ثم `npm run dev`، وبعدها انشر التطبيق على HTTPS باش تخدم الكاميرا.
9. من حساب Admin: Import Excel > Affectation > اختار الطرود والـ livreur. تنجم زادة تختار "Moi-même (Admin)" للطرود اللي باش توصلهم إنت.
10. الـ livreur يدخل بحسابه، يعمل scan ويبدّل الحالة إلى Livré / Absent / Refusé / Retour.

**مهم:** النسخة هاذي source code أولي يلزم ربطه بمشروع Supabase ونشره واختباره بحسابات تجريبية قبل استعماله مع فلوس وطرود حقيقية.
