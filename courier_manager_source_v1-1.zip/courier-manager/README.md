# Courier Manager — première version

Application web responsive (installable comme PWA sur Android) pour gérer un dépôt et plusieurs livreurs.

## Fonctions incluses
- Connexion email / mot de passe via Supabase Auth.
- Rôles ADMIN et LIVREUR.
- Import Excel/CSV des colis (colonnes reconnues : code/code colis/tracking, client/nom, téléphone/tel, adresse, COD/montant).
- Import en masse, doublons ignorés grâce au code colis unique.
- Affectation des colis en attente à un livreur ou à l'admin lui-même (commission admin 5 DT).
- Liste filtrée selon les droits du compte.
- Lecture code-barres par caméra (HTTPS requis) et recherche manuelle.
- Mise à jour des statuts.
- Tableau de bord et calculs de commissions.
- Synchronisation temps réel via Supabase Realtime (à activer dans le projet).

## Règles de commission prévues
- Admin livre personnellement : 5 DT / colis livré.
- Livreur : commission paramétrable, valeur initiale 4 DT.
- Marge admin sur colis livré par un livreur : 5 - commission livreur (1 DT si commission = 4 DT).
- Absent, refusé et retour : aucune commission.
- Le COD à remettre est estimé comme COD livré moins commissions. Confirmer avec l'expéditeur le mécanisme réel de reversement.

## Ce qui est nécessaire pour la mise en ligne
Cette archive est le code source d'une première version, pas encore un site hébergé ni un APK prêt à installer. Le mode multi-comptes réel nécessite un projet Supabase configuré et un hébergement HTTPS.

### 1. Créer Supabase
1. Créer un projet sur https://supabase.com.
2. Dans Project Settings > API, copier Project URL et anon/public key.
3. Dupliquer `.env.example` en `.env` et renseigner les deux valeurs.
4. Dans SQL Editor, exécuter `supabase/schema.sql`.

### 2. Créer les comptes
1. Dans Supabase > Authentication > Users, créer ton compte admin.
2. Copier son User UID.
3. Dans SQL Editor, exécuter l'INSERT admin commenté à la fin de `supabase/schema.sql`, avec ton UID, ton email et ton nom.
4. Créer chaque compte livreur dans Authentication > Users.
5. Pour chaque compte, ajouter une ligne dans `profiles` avec son Auth UID, son nom, son email, le rôle `courier` et sa commission (4 DT par défaut).
6. Ne partage jamais la clé `service_role` dans l'application ou dans un navigateur.

> Dans cette première version, la création des identifiants se fait dans le tableau de bord Supabase. L'écran ADMIN liste les livreurs et permet de modifier leur commission. Un formulaire sécurisé d'invitation des livreurs via Edge Function peut être ajouté dans une étape suivante.

### 3. Activer le temps réel
Dans Supabase > Database > Replication (ou Publications), activer `profiles` et `shipments` pour Realtime.

### 4. Lancer en local
Installer Node.js 20+ puis :
```bash
npm install
cp .env.example .env
# remplir .env
npm run dev
```
Ouvrir l'adresse locale indiquée par Vite.

### 5. Déployer en HTTPS
Déployer le projet sur Vercel, Netlify ou un hébergeur statique HTTPS. Ajouter les mêmes variables d'environnement `VITE_SUPABASE_URL` et `VITE_SUPABASE_ANON_KEY` dans les paramètres de déploiement. La caméra du téléphone exige HTTPS (ou localhost).

### 6. Installer sur Android
Ouvrir l'URL HTTPS dans Chrome Android > menu ⋮ > Installer l'application / Ajouter à l'écran d'accueil.

## Format Excel conseillé
La première feuille doit contenir une ligne d'en-têtes. Exemple :
| Code colis | Client | Téléphone | Adresse | COD |
|---|---|---|---|---:|
| TN001 | Client test | 20123456 | Tunis | 85 |
| TN002 | Client test 2 | 22123456 | Ariana | 120 |

Le code colis doit être unique. Le code scanné doit correspondre exactement à la colonne Code colis.

## Limites et vérifications avant usage réel
- Cette version est un socle fonctionnel à connecter et tester, pas un système comptable certifié.
- Les statuts et droits doivent être testés avec plusieurs comptes avant de gérer de vrais colis.
- Le dashboard livreur ne voit que les colis qui lui sont affectés.
- Les règles RLS protègent les données par compte ; un audit supplémentaire est recommandé avant production.
- Le calcul actuel suppose une commission de 5 DT pour les colis livrés par l'admin et un coût livreur paramétré, avec une marge admin égale à 5 moins cette commission.
- La gestion des remises COD, paiements partiels, retours encaissés, historique des changements et clôture journalière complète sont des améliorations à finaliser selon les procédures exactes du dépôt.
